import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';


import { AppComponent } from './app.component';
import { Demo1Component } from './demo1/demo1.component';
import {AngularBasicsComponent} from './angular-basics/angular-basics.component'
import {TechnologyComponent} from './technology/technology.component';
import { RedDirectiveDirective } from './red-directive.directive';
import { MyDirectiveDirective } from './my-directive.directive';
import { DirectiveDemoComponent } from './directive-demo/directive-demo.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderbyPipe } from './pipes/orderby.pipe';
import { ServiceDemoComponent } from './service-demo/service-demo.component';
import { UsersComponent } from './users/users.component'
import {UsersService} from './service/users.service';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component';
import { NestedComponent } from './nested/nested.component';
import {TemplateComponent} from './template/template.component'
import {ReactiveComponent} from './reactive/reactive.component'
@NgModule({
  //Component,Directives,Pipes
  declarations: [
    AppComponent,
    Demo1Component,
    AngularBasicsComponent,
    TechnologyComponent,
    RedDirectiveDirective,
    MyDirectiveDirective,
    DirectiveDemoComponent,
    PipeDemoComponent,
    GenderPipe,
    OrderbyPipe,
    ServiceDemoComponent,
    UsersComponent,
    ChildComponent,
    ParentComponent,
    NestedComponent,
    TemplateComponent,
    ReactiveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [UsersService],
  bootstrap: [AppComponent]
})
export class AppModule { }

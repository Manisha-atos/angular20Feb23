export class Product {    
  public id: number;    
  public name:string;
  public rate:number;
  constructor( id: number,name:string,rate:number,)    
  {    
    this.id = id;   
    this.name=name;
    this.rate=rate; 
  }  
// constructor()
// {

// }  
}  
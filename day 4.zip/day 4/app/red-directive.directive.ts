import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appRedDirective]'
})
export class RedDirectiveDirective {

  constructor(elRef: ElementRef) { 

     elRef.nativeElement.style.color = 'red';
  }

}

import { Component } from '@angular/core';
import { UsersService } from '../service/users.service'
import { Observable, throwError } from 'rxjs';
import {User} from '../User';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
title="User Details";
  user:any;
  userId:number=1;
  message="";
  users:User[]= [];
  constructor(private us:UsersService) {
    console.log("UsersComponent created......");
   
  }
  getAllUsers(){
    console.log("get all users called..")
     this.us.getAllUsers()
            .subscribe((response)=>{this.users=response}
            ,
            (err)=>{this.message=err});
   //  this.users=this.us.getAllUsers();
            console.log(this.users)

           
            
       

     }

      getUser(){
    
    this.us.getUserByUserId(this.userId)
           .subscribe(response=>this.user=response,error=>this.message=error);
      }

      deleteUserById(id:number){
       this.us.deleteUserById(id)
              .subscribe(response=>this.user=response,err=>this.message=err);
              this.getAllUsers();
         }

         getUserById(id:number){
       this.us.getUserById(id)
              .subscribe(response=>this.user=response,err=>this.message=err);
       }
       updateUserById(id:number){
         console.log(id);
           this.us.updateUserById(id,this.user)
                  .subscribe(response=>this.users=response,err=>this.message=err);
    this.getAllUsers();
           }
            addUser(){
            this.us.addUserById(this.user)
                    .subscribe(response=>this.users=response,err=>this.message=err);
       
             }
     ngOnInit() {
    console.log("UsersComponent initialized........"+this.userId);
this.getAllUsers();
  //this.getUser();
 
    //this.getUserById(1);
     
  }
}

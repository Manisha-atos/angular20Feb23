import { RedDirectiveDirective } from './red-directive.directive';

describe('RedDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new RedDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});

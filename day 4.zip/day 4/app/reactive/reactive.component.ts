import { Component, OnInit } from '@angular/core';
import {FormGroup,FormBuilder,Validator, Validators,FormControl} from "@angular/forms";
@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
  userForm = new FormGroup({  
    firstName: new FormControl('Kumar',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),  
    email: new FormControl(),  
    address: new FormGroup({  
        country: new FormControl(),  
        city: new FormControl(),  
        postalCode: new FormControl(null,Validators.pattern('^[1-9][0-9]{4}$'))  
    })  
});  

submitForm() {  
    console.log(this.userForm.value);  

}
}

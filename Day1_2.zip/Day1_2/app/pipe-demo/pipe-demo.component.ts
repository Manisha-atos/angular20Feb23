import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe-demo',
  templateUrl: './pipe-demo.component.html',
  styleUrls: ['./pipe-demo.component.css']
})
export class PipeDemoComponent {
  fname='mAnisha'
  sal=2356.883456;
d=new Date();
name={fname:'Manisha',lname:'Kiran'};


}

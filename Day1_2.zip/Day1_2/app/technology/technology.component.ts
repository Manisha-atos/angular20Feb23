import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit ,OnDestroy {

  title='Top 5 Technologies';

  technologies=[
    {id:101,name:'Angular',likes:0,dislikes:0},
    {id:102,name:'Micro services',likes:0,dislikes:0},
    {id:103,name:'AWS',likes:0,dislikes:0},
    {id:104,name:'Spring Boot',likes:0,dislikes:0},
    {id:105,name:'Data Science',likes:0,dislikes:0},
   ];






  constructor() {
console.log("TechnologyComponent created...");

   }

  ngOnInit() {
    console.log("TechnologyComponent initialized...");

  }
  ngOnDestroy() {
    console.log("TechnologyComponent destroyed...");

  }


  incrementLikes(t:any){
    t.likes++;
  }

  incrementDislikes(t:any){
    t.dislikes++;
  }
    


}

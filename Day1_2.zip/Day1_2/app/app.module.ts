import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Demo1Component } from './demo1/demo1.component';
import {AngularBasicsComponent} from './angular-basics/angular-basics.component'
import {TechnologyComponent} from './technology/technology.component';
import { RedDirectiveDirective } from './red-directive.directive';
import { MyDirectiveDirective } from './my-directive.directive';
import { DirectiveDemoComponent } from './directive-demo/directive-demo.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component'

@NgModule({
  declarations: [
    AppComponent,
    Demo1Component,
    AngularBasicsComponent,
    TechnologyComponent,
    RedDirectiveDirective,
    MyDirectiveDirective,
    DirectiveDemoComponent,
    PipeDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Injectable } from '@angular/core';
import {Product} from '../Product'

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  public p:Product;
public idx:number=0;
//public Prds:Product[]=[];
constructor()
{
this.p={id:0,name:"",rate:0};
}


  getProducts()
  { 
    
    return [
      {id: 10,name:'Prod10', rate: 30},
      {id: 20,name:'Prod20', rate: 50},
      {id: 30,name:'Prod30', rate: 20},
      {id: 40,name:'Prod40', rate: 80}
    ];
  
  }
}
 /* addProduct()
  {
this.Prds.push({id:1,name:'Mobile',rate:9999});
  }
  addNewProduct (p:Products)
  {
this.Prds.push(p);
  }
  getProductById(id)
  {
    this.idx=this.Prds.indexOf(id);
   this.p =this.Prds[this.idx]
    return this.p;

  }
}
*/
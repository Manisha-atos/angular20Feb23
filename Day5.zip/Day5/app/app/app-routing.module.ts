import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {Demo1Component} from '../demo1/demo1.component';
import {DirectiveDemoComponent} from '../directive-demo/directive-demo.component'
import {TechnologyComponent} from '../technology/technology.component'
import {PipeDemoComponent} from '../pipe-demo/pipe-demo.component';
import {TemplateComponent} from '../template/template.component';
import {AngularBasicsComponent} from '../angular-basics/angular-basics.component';
import {UsersComponent} from '../users/users.component'

const routes: Routes = [
{path:'basics',component:AngularBasicsComponent},
  {path:'technology',component:TechnologyComponent},
  {path:'pipes',component:PipeDemoComponent},
  {path:'directive',component:DirectiveDemoComponent},  
  {path:'template',component:TemplateComponent},
  {path:'RestAPI',component:UsersComponent},
  {path:'**', redirectTo:"basics"},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

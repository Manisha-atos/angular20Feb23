import { Component } from '@angular/core';
import {ProductService} from '../service/product.service';
import {Product} from '../Product';
import { Observable, throwError } from 'rxjs';
@Component({
  selector: 'app-service-demo',
  templateUrl: './service-demo.component.html',
  styleUrls: ['./service-demo.component.css']
})
export class ServiceDemoComponent {
  products:Product[]=[];  
 productService; 
 constructor(private p:ProductService){  
     this.productService=p;  
   }
   getAllProducts() {       
     this.products=this.productService.getProducts();  
   } 
}

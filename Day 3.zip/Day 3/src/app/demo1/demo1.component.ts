import { Component } from '@angular/core';

@Component({
  selector: 'app-demo1',
  templateUrl: './demo1.component.html',
  styleUrls: ['./demo1.component.css']
})
export class Demo1Component {
  title:string='Welcome to Angular'
name:String='Manisha';
lname:string='Kiran';
public show()
{
alert("hi");
console.log(this.lname);
}
}

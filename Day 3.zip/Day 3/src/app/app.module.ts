import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';


import { AppComponent } from './app.component';
import { Demo1Component } from './demo1/demo1.component';
import {AngularBasicsComponent} from './angular-basics/angular-basics.component'
import {TechnologyComponent} from './technology/technology.component';
import { RedDirectiveDirective } from './red-directive.directive';
import { MyDirectiveDirective } from './my-directive.directive';
import { DirectiveDemoComponent } from './directive-demo/directive-demo.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { GenderPipe } from './pipes/gender.pipe';
import { OrderbyPipe } from './pipes/orderby.pipe';
import { ServiceDemoComponent } from './service-demo/service-demo.component';
import { UsersComponent } from './users/users.component'
import {UsersService} from './service/users.service';
@NgModule({
  //Component,Directives,Pipes
  declarations: [
    AppComponent,
    Demo1Component,
    AngularBasicsComponent,
    TechnologyComponent,
    RedDirectiveDirective,
    MyDirectiveDirective,
    DirectiveDemoComponent,
    PipeDemoComponent,
    GenderPipe,
    OrderbyPipe,
    ServiceDemoComponent,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [UsersService],
  bootstrap: [AppComponent]
})
export class AppModule { }

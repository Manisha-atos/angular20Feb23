import { Component } from '@angular/core';
import { UsersService } from '../service/users.service'
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {
title="User Details";
  user:any;
  userId:number=1;
  message="";
  users=[];
  constructor(private us:UsersService) {
    console.log("UsersComponent created......");
   
  }
  getAllUsers(){
    console.log("get all users called..")
     this.us.getAllUsers()
            .subscribe(response=>this.users=response,err=>this.message=err);
    // this.users=this.us.getAllUsers();
            console.log(this.users)

     }
     ngOnInit() {
    console.log("UsersComponent initialized........"+this.userId);
this.getAllUsers();
  //this.getUser();
 
    //this.getUserById(1);
     
  }
}
